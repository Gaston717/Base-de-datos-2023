show databases;

use base_gaston01;

create table CLIENTES (
ClienteID integer not null auto_increment primary key,
Nombre varchar (25),
Apellido varchar (25),
CUIT char(16),
Direccion varchar (50),
Comentarios varchar (50)
);

show tables;

describe CLIENTES;

create table FACTURAS (
Letra char primary key auto_increment,
Numero integer primary key auto_increment,
ClienteID integer,
ArticuloID integer,
Fecha date,
Monto double
);

describe FACTURAS;

