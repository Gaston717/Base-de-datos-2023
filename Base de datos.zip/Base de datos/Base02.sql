/*
Ejercicio Nro 2
*/

show databases;
create database base_gaston01;
show databases;

use base_gaston01; -- ingresar a la base de datos creada

create table productos (  -- crea tabla "(" inicio y ");" fin. No se pueden crear dos tablas con el mismo nombre. 
idProducto int (14) unsigned not null auto_increment primary key, -- como maximo 14 espacios, unsigned porque son numeros positivos, not null no lleva espacios vacios, primary key es la clave y la "," separa los campos.
nombreProducto varchar (50) not null, 
descripcion varchar (100) not null, -- en general es recomendable poner not null (no vacío) a todo para que haya mas determinacion en el producto
marca varchar (40) not null, 
precio float unsigned,
cantidad int (6) unsigned);

show tables;			-- muestra las tablas
describe productos;		-- describe la tabla seleccionada
-- show charset;			-- muestra todos los caracteres que se pueden utilizar

alter table productos ADD column vencimiento date;	-- alterar tabla productos y agregar columna vencimento 

describe productos;

alter table productos change vencimiento fecha_vencimiento date;	-- cambia el nombre de la columna y el tipo de dato

alter table productos modify precio double;		-- cambia el tipo de variable

alter table productos drop column marca;		-- elimina la columna marca

alter table productos rename Articulos;			-- cambia el nombre de la tabla

describe Articulos;

-- eliminar restricciones ej, not null   primary key

-- ALTER TABLE user_customer_permission MODIFY id INT NOT NULL;
-- ALTER TABLE user_customer_permission DROP PRIMARY KEY;





