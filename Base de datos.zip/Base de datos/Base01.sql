/*
comentario: 
- El lenguaje NO es case sensitive
- los 1000 rows son tenidos en cuenta al momento
de programar para una pagina.
*/
-- comentario de 1 sola linea, debe haber un espacio en las dos rayas y el texto
#comentarios, no se encuentra dentro de la norma ANSI

show databases;

SHOW DATABASES;  -- no es case sensitive


create database base01;